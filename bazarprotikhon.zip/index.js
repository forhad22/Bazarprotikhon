// // // index.js

// // const express = require('express');
// // const bodyParser = require('body-parser');
// // const cors = require('cors');
// // const jwt = require('jsonwebtoken');
// // require('dotenv').config();

// // const sequelize = require('./config/database');
// // const User = require('./models/User');
// // const Transaction = require('./models/Transaction');
// // const authenticateToken = require('./middleware/auth');
// // //const cors = require('cors');
// // const app = express();
// // //const PORT = process.env.PORT || 3000;
// // const PORT = 5000;

// // // Middleware
// // app.use(bodyParser.json());
// // app.use(cors());

// // // Database connection
// // sequelize.sync().then(() => {
// //   console.log('Connected to MariaDB');
// // }).catch((err) => {
// //   console.error('Error connecting to MariaDB:', err);
// // });

// // // Routes

// // // রেজিস্ট্রেশন রুট
// // app.post('/register', async (req, res) => {
// //   const { name, email, phone, password, userType, referralCode } = req.body;

// //   if (!email && !phone) {
// //     return res.status(400).send('Please provide at least an email or phone number.');
// //   }

// //   try {
// //     // চেক করুন ইমেইল বা ফোন নম্বর ইতোমধ্যে নিবন্ধিত কিনা
// //     if (email) {
// //       const existingEmail = await User.findOne({ where: { email } });
// //       if (existingEmail) {
// //         return res.status(400).send('Email already registered.');
// //       }
// //     }

// //     if (phone) {
// //       const existingPhone = await User.findOne({ where: { phone } });
// //       if (existingPhone) {
// //         return res.status(400).send('Phone number already registered.');
// //       }
// //     }

// //     let customerId = null;

// //     if (userType === 'customer') {
// //       const lastCustomer = await User.findOne({ where: { userType: 'customer' }, order: [['id', 'DESC']] });
// //       let newCustomerId = 'bp2401';

// //       if (lastCustomer && lastCustomer.customerId) {
// //         const lastIdNumber = parseInt(lastCustomer.customerId.slice(2));
// //         newCustomerId = `bp${lastIdNumber + 1}`;
// //       }

// //       customerId = newCustomerId;
// //     }

// //     const user = await User.create({
// //       name,
// //       email,
// //       phone,
// //       password,
// //       userType,
// //       customerId,
// //       referralCode,
// //     });

// //     // রেফারেল ব্যবস্থাপনা
// //     if (referralCode) {
// //       const referrer = await User.findOne({ where: { customerId: referralCode } });
// //       if (referrer) {
// //         user.referredBy = referrer.customerId;
// //         await user.save();
// //         // এখানে রেফারারকে কমিশন প্রদান করতে পারেন
// //       }
// //     }

// //     res.status(201).json({ message: 'User registered successfully', customerId: user.customerId });
// //   } catch (err) {
// //     console.error(err);
// //     res.status(500).send('Error registering user');
// //   }
// // });







// // // Login Route

// // // index.js

// // // আগের ইমপোর্টগুলি
// // const { Op } = require('sequelize'); // Op ইমপোর্ট করা হয়েছে

// // // লগইন রুট
// // app.post('/api/login/:userType', async (req, res) => {
// //   const { identifier, password } = req.body;
// //   const { userType } = req.params;

// //   if (!identifier || !password) {
// //     return res.status(400).send('Please provide identifier and password.');
// //   }

// //   try {
// //     // ইউজার খুঁজুন ইমেইল বা ফোন নম্বর দিয়ে
// //     const user = await User.findOne({
// //       where: {
// //         userType,
// //         [Op.or]: [{ email: identifier }, { phone: identifier }],
// //       },
// //     });

// //     if (!user || user.password !== password) {
// //       return res.status(400).send('Invalid credentials');
// //     }

// //     const token = jwt.sign({ _id: user.id, userType: user.userType }, process.env.JWT_SECRET, {
// //       expiresIn: process.env.JWT_EXPIRATION,
// //     });

// //     res.send({ token });
// //   } catch (error) {
// //     console.error(error);
// //     res.status(500).send('Server error');
// //   }
// // });


// // // app.post('/api/login/:userType', async (req, res) => {
// // //   const { email, password } = req.body;
// // //   const { userType } = req.params;

// // //   try {
// // //     // ব্যবহারকারী খোঁজা
// // //     const user = await User.findOne({ where: { email, userType } });
// // //     if (!user) {
// // //       return res.status(400).send('User not found');
// // //     }

// // //     // পাসওয়ার্ড যাচাই করা
// // //     if (user.password !== password) {
// // //       return res.status(400).send('Incorrect password');
// // //     }

// // //     // JWT টোকেন তৈরি
// // //     const token = jwt.sign(
// // //       { _id: user.id, userType: user.userType },
// // //       process.env.JWT_SECRET,
// // //       { expiresIn: process.env.JWT_EXPIRATION }
// // //     );

// // //     // সফল লগইন এ টোকেন পাঠানো
// // //     res.send({ token });
// // //   } catch (error) {
// // //     res.status(500).send('Server error');
// // //   }
// // // });






// // // Customer Dashboard Route
// // // app.get('/dashboard/customer', authenticateToken, async (req, res) => {
// // //   try {
// // //     const user = await User.findByPk(req.user._id);
// // //     if (!user || user.userType !== 'customer') {
// // //       return res.status(403).send('Access denied');
// // //     }

// // //     // রেফার করা ইউজারদের খুঁজে বের করা
// // //     const referredUsers = await User.findAll({ where: { referredBy: user.customerId } });

// // //     res.json({
// // //       name: user.name,
// // //       email: user.email,
// // //       points: user.points,
// // //       customerId: user.customerId,
// // //       isGoldenCustomer: user.isGoldenCustomer,
// // //       referredUsers: referredUsers.map(u => ({ name: u.name, customerId: u.customerId })),
// // //     });
// // //   } catch (err) {
// // //     res.status(500).send('Server error');
// // //   }
// // // });


// // app.get('/dashboard/customer', authenticateToken, async (req, res) => {
// //   try {
// //     const user = await User.findByPk(req.user._id);
// //     if (!user || user.userType !== 'customer') {
// //       return res.status(403).send('Access denied');
// //     }

// //     // রেফার করা ইউজারদের খুঁজে বের করা
// //     const referredUsers = await User.findAll({ where: { referredBy: user.customerId } });

// //     res.json({
// //       name: user.name,
// //       email: user.email,
// //       phone: user.phone,  // এখানে ফোন নম্বর যোগ করা হয়েছে
// //       points: user.points,
// //       customerId: user.customerId,
// //       isGoldenCustomer: user.isGoldenCustomer,
// //       referredUsers: referredUsers.map(u => ({ name: u.name, customerId: u.customerId })),
// //     });
// //   } catch (err) {
// //     res.status(500).send('Server error');
// //   }
// // });





// // // Seller Assign Cashback Route
// // app.post('/dashboard/seller/assign-cashback', authenticateToken, async (req, res) => {
// //   const { customerId, amount } = req.body;

// //   try {
// //     const seller = await User.findByPk(req.user._id);
// //     if (!seller || seller.userType !== 'seller') {
// //       return res.status(403).send('Access denied');
// //     }

// //     // কাস্টমার খুঁজে পাওয়া
// //     const customer = await User.findOne({ where: { customerId } });
// //     if (!customer) {
// //       return res.status(404).send('Customer not found');
// //     }

// //     // পয়েন্ট কনভার্ট করা
// //     const pointsEarned = parseFloat(amount) / 5;
// //     customer.points += pointsEarned;

// //     // গোল্ডেন কাস্টমার চেক করা
// //     if (customer.points >= 100) {
// //       customer.isGoldenCustomer = true;
// //     }

// //     await customer.save();

// //     // ট্রান্সাকশন লগ করা
// //     await Transaction.create({
// //       customerId: customer.customerId,
// //       sellerId: seller.id,
// //       amount,
// //       pointsEarned,
// //     });

// //     res.json({
// //       message: 'Cashback assigned successfully',
// //       customerId: customer.customerId,
// //       updatedPoints: customer.points,
// //     });
// //   } catch (err) {
// //     res.status(500).send('Server error');
// //   }
// // });

// // // Serve React App
// // const path = require('path');

// // app.use(express.static(path.join(__dirname, 'client', 'build')));

// // app.get('*', (req, res) => {
// //   res.sendFile(path.join(__dirname, 'client', 'build', 'index.html'));
// // });

// // // index.js

// // // Database connection
// // sequelize.sync({ alter: true }).then(() => {
// //   console.log('Connected to MariaDB');
// // }).catch((err) => {
// //   console.error('Error connecting to MariaDB:', err);
// // });




// // // Start the server
// // app.listen(PORT, () => {
// //   console.log(`Server is running on port ${PORT}`);
// // });











// // index.js

// const express = require('express');
// const bodyParser = require('body-parser');
// const cors = require('cors');
// const jwt = require('jsonwebtoken');
// require('dotenv').config();

// const sequelize = require('./config/database');
// const User = require('./models/User');
// const Transaction = require('./models/Transaction');
// const authenticateToken = require('./middleware/auth');
// //const cors = require('cors');
// const app = express();
// //const PORT = process.env.PORT || 3000;
// const PORT = 5000;

// // Middleware
// app.use(bodyParser.json());
// app.use(cors());

// // Database connection
// sequelize.sync().then(() => {
//   console.log('Connected to MariaDB');
// }).catch((err) => {
//   console.error('Error connecting to MariaDB:', err);
// });

// // Routes

// // রেজিস্ট্রেশন রুট
// app.post('/register', async (req, res) => {
//   const { name, phone, password, userType, referralCode } = req.body;

//   if (!phone) {
//     return res.status(400).send('Please provide phone number.');
//   }

//   try {
//     // চেক করুন ফোন নম্বর ইতোমধ্যে নিবন্ধিত কিনা
//     const existingPhone = await User.findOne({ where: { phone } });
//     if (existingPhone) {
//       return res.status(400).send('Phone number already registered.');
//     }

//     let customerId = null;

//     if (userType === 'customer') {
//       const lastCustomer = await User.findOne({ where: { userType: 'customer' }, order: [['id', 'DESC']] });
//       let newCustomerId = 'bp2401';

//       if (lastCustomer && lastCustomer.customerId) {
//         const lastIdNumber = parseInt(lastCustomer.customerId.slice(2));
//         newCustomerId = `bp${lastIdNumber + 1}`;
//       }

//       customerId = newCustomerId;
//     }

//     const user = await User.create({
//       name,
//       phone,
//       password,
//       userType,
//       customerId,
//       referralCode,
//     });

//     // রেফারেল ব্যবস্থাপনা
//     if (referralCode) {
//       const referrer = await User.findOne({ where: { customerId: referralCode } });
//       if (referrer) {
//         user.referredBy = referrer.customerId;
//         await user.save();
//         // এখানে রেফারারকে কমিশন প্রদান করতে পারেন
//       }
//     }

//     res.status(201).json({ message: 'User registered successfully', customerId: user.customerId });
//   } catch (err) {
//     console.error(err);
//     res.status(500).send('Error registering user');
//   }
// });

// // Login Route
// const { Op } = require('sequelize'); // Op ইমপোর্ট করা হয়েছে

// app.post('/api/login/:userType', async (req, res) => {
//   const { identifier, password } = req.body;
//   const { userType } = req.params;

//   if (!identifier || !password) {
//     return res.status(400).send('Please provide phone number and password.');
//   }

//   try {
//     // ইউজার খুঁজুন ফোন নম্বর দিয়ে
//     const user = await User.findOne({
//       where: {
//         userType,
//         phone: identifier,  // শুধু ফোন নম্বর দিয়ে খুঁজে বের করা হচ্ছে
//       },
//     });

//     if (!user || user.password !== password) {
//       return res.status(400).send('Invalid credentials');
//     }

//     const token = jwt.sign({ _id: user.id, userType: user.userType }, process.env.JWT_SECRET, {
//       expiresIn: process.env.JWT_EXPIRATION,
//     });

//     res.send({ token });
//   } catch (error) {
//     console.error(error);
//     res.status(500).send('Server error');
//   }
// });

// // Customer Dashboard Route
// app.get('/dashboard/customer', authenticateToken, async (req, res) => {
//   try {
//     const user = await User.findByPk(req.user._id);
//     if (!user || user.userType !== 'customer') {
//       return res.status(403).send('Access denied');
//     }

//     // রেফার করা ইউজারদের খুঁজে বের করা
//     const referredUsers = await User.findAll({ where: { referredBy: user.customerId } });

//     res.json({
//       name: user.name,
//       phone: user.phone,  // এখানে ফোন নম্বর যোগ করা হয়েছে
//       points: user.points,
//       customerId: user.customerId,
//       isGoldenCustomer: user.isGoldenCustomer,
//       referredUsers: referredUsers.map(u => ({ name: u.name, customerId: u.customerId })),
//     });
//   } catch (err) {
//     res.status(500).send('Server error');
//   }
// });

// // Seller Assign Cashback Route
// app.post('/dashboard/seller/assign-cashback', authenticateToken, async (req, res) => {
//   const { customerId, amount } = req.body;

//   try {
//     const seller = await User.findByPk(req.user._id);
//     if (!seller || seller.userType !== 'seller') {
//       return res.status(403).send('Access denied');
//     }

//     // কাস্টমার খুঁজে পাওয়া
//     const customer = await User.findOne({ where: { customerId } });
//     if (!customer) {
//       return res.status(404).send('Customer not found');
//     }

//     // পয়েন্ট কনভার্ট করা
//     const pointsEarned = parseFloat(amount) / 5;
//     customer.points += pointsEarned;

//     // গোল্ডেন কাস্টমার চেক করা
//     if (customer.points >= 100) {
//       customer.isGoldenCustomer = true;
//     }

//     await customer.save();

//     // ট্রান্সাকশন লগ করা
//     await Transaction.create({
//       customerId: customer.customerId,
//       sellerId: seller.id,
//       amount,
//       pointsEarned,
//     });

//     res.json({
//       message: 'Cashback assigned successfully',
//       customerId: customer.customerId,
//       updatedPoints: customer.points,
//     });
//   } catch (err) {
//     res.status(500).send('Server error');
//   }
// });

// // Serve React App
// const path = require('path');

// app.use(express.static(path.join(__dirname, 'client', 'build')));

// app.get('*', (req, res) => {
//   res.sendFile(path.join(__dirname, 'client', 'build', 'index.html'));
// });

// // Database connection
// sequelize.sync({ alter: true }).then(() => {
//   console.log('Connected to MariaDB');
// }).catch((err) => {
//   console.error('Error connecting to MariaDB:', err);
// });

// // Start the server
// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}`);
// });













// index.js

// const express = require('express');
// const bodyParser = require('body-parser');
// const cors = require('cors');
// const jwt = require('jsonwebtoken');
// require('dotenv').config();

// const sequelize = require('./config/database');
// const User = require('./models/User');
// const Transaction = require('./models/Transaction');
// const Message = require('./models/Message');
// const WithdrawRequest = require('./models/WithdrawRequest');
// const Fund = require('./models/Fund');
// const authenticateToken = require('./middleware/auth');
// const { Op } = require('sequelize');
// const referralCodes = require('./config/referralCodes');
// const cron = require('node-cron');

// const app = express();
// const PORT = 5000;

// // Middleware
// app.use(bodyParser.json());
// app.use(cors());

// // Database connection
// sequelize.sync({ alter: true }).then(async () => {
//   console.log('Connected to MariaDB');

//   // Ensure a Fund record exists
//   const fundRecord = await Fund.findOne();
//   if (!fundRecord) {
//     await Fund.create({});
//   }
// }).catch((err) => {
//   console.error('Error connecting to MariaDB:', err);
// });

// // Routes

// // Registration Route
// app.post('/register', async (req, res) => {
//   const { name, phone, password, userType, referralCode } = req.body;

//   if (!phone) {
//     return res.status(400).send('Please provide phone number.');
//   }

//   try {
//     // Check if phone number already exists
//     const existingPhone = await User.findOne({ where: { phone } });
//     if (existingPhone) {
//       return res.status(400).send('Phone number already registered.');
//     }

//     let customerId = null;

//     if (userType === 'customer') {
//       const lastCustomer = await User.findOne({ where: { userType: 'customer' }, order: [['id', 'DESC']] });
//       let newCustomerId = 'bp2401';

//       if (lastCustomer && lastCustomer.customerId) {
//         const lastIdNumber = parseInt(lastCustomer.customerId.slice(2));
//         newCustomerId = `bp${lastIdNumber + 1}`;
//       }

//       customerId = newCustomerId;
//     }

//     const user = await User.create({
//       name,
//       phone,
//       password,
//       userType,
//       customerId,
//     });

//     // Referral management
//     let referrerCode = referralCode;

//     if (!referrerCode) {
//       // Auto referral code selection
//       const usedCodes = await User.findAll({
//         attributes: ['referralCode'],
//         where: { referralCode: { [Op.in]: referralCodes } },
//       });
//       const usedCodesSet = new Set(usedCodes.map(u => u.referralCode));
//       const availableCodes = referralCodes.filter(code => !usedCodesSet.has(code));

//       if (availableCodes.length > 0) {
//         referrerCode = availableCodes[0]; // Use the first available code
//       } else {
//         referrerCode = referralCodes[0]; // If all codes are used, recycle from the beginning
//       }
//     }

//     user.referralCode = customerId; // Assign customer's own referral code
//     user.referredBy = referrerCode; // Set referrer code

//     await user.save();

//     res.status(201).json({ message: 'User registered successfully', customerId: user.customerId });
//   } catch (err) {
//     console.error(err);
//     res.status(500).send('Error registering user');
//   }
// });

// // Login Route
// app.post('/api/login/:userType', async (req, res) => {
//   const { identifier, password } = req.body;
//   const { userType } = req.params;

//   if (!identifier || !password) {
//     return res.status(400).send('Please provide phone number and password.');
//   }

//   try {
//     // Find user by phone number
//     const user = await User.findOne({
//       where: {
//         userType,
//         phone: identifier,
//       },
//     });

//     if (!user || user.password !== password) {
//       return res.status(400).send('Invalid credentials');
//     }

//     const token = jwt.sign({ _id: user.id, userType: user.userType }, process.env.JWT_SECRET, {
//       expiresIn: process.env.JWT_EXPIRATION,
//     });

//     res.send({ token });
//   } catch (error) {
//     console.error(error);
//     res.status(500).send('Server error');
//   }
// });

// // Customer Dashboard Route
// app.get('/dashboard/customer', authenticateToken, async (req, res) => {
//   try {
//     const user = await User.findByPk(req.user._id);
//     if (!user || user.userType !== 'customer') {
//       return res.status(403).send('Access denied');
//     }

//     // Find referred users
//     const referredUsers = await User.findAll({ where: { referredBy: user.customerId } });

//     // Get the latest message
//     const latestMessage = await Message.findOne({ order: [['createdAt', 'DESC']] });

//     res.json({
//       name: user.name,
//       phone: user.phone,
//       points: user.points,
//       balance: user.balance,
//       earnedBonus: user.earnedBonus,
//       earnedRoyalty: user.earnedRoyalty,
//       earnedIncentive: user.earnedIncentive,
//       earnedReferral: user.earnedReferral,
//       customerId: user.customerId,
//       isGoldenCustomer: user.isGoldenCustomer,
//       referredUsers: referredUsers.map(u => ({ name: u.name, customerId: u.customerId })),
//       totalReferrals: referredUsers.length,
//       message: latestMessage ? latestMessage.content : null,
//     });
//   } catch (err) {
//     console.error(err);
//     res.status(500).send('Server error');
//   }
// });

// // Seller Assign Cashback Route
// app.post('/dashboard/seller/assign-cashback', authenticateToken, async (req, res) => {
//   const { customerId, amount } = req.body;

//   try {
//     const seller = await User.findByPk(req.user._id);
//     if (!seller || seller.userType !== 'seller') {
//       return res.status(403).send('Access denied');
//     }

//     // Find customer
//     const customer = await User.findOne({ where: { customerId } });
//     if (!customer) {
//       return res.status(404).send('Customer not found');
//     }

//     // Convert amount to points
//     const pointsEarned = parseFloat(amount) / 5;
//     customer.points += pointsEarned;

//     // Check for golden customer
//     if (customer.points >= 100) {
//       customer.isGoldenCustomer = true;
//     }

//     await customer.save();

//     // Log transaction
//     await Transaction.create({
//       customerId: customer.customerId,
//       sellerId: seller.id,
//       amount,
//       pointsEarned,
//     });

//     // Fetch fund record
//     const fund = await Fund.findOne();

//     // Referral income calculation
//     const referralIncomeTotal = amount * 0.05; // 5% referral income
//     const generationIncomes = [
//       { percentage: 0.40, level: 1 },
//       { percentage: 0.30, level: 2 },
//       { percentage: 0.30, level: 3 },
//     ];

//     let currentReferrerId = customer.referredBy;
//     for (const income of generationIncomes) {
//       if (!currentReferrerId) break;

//       const referrer = await User.findOne({ where: { customerId: currentReferrerId } });
//       if (referrer) {
//         const incomeAmount = referralIncomeTotal * income.percentage;
//         referrer.balance = (referrer.balance || 0) + incomeAmount;
//         referrer.earnedReferral = (referrer.earnedReferral || 0) + incomeAmount; // Update earned referral income

//         await referrer.save();

//         // Move to next upline referrer
//         currentReferrerId = referrer.referredBy;
//       } else {
//         break;
//       }
//     }

//     // Seller income
//     const sellerIncome = amount * 0.10;
//     seller.balance = (seller.balance || 0) + sellerIncome;
//     await seller.save();

//     // Update funds
//     const bonusAmount = amount * 0.40;
//     const royaltyAmount = amount * 0.10;
//     const incentiveAmount = amount * 0.20;
//     const companyIncome = amount * 0.15;

//     fund.bonusFund += bonusAmount;
//     fund.royaltyFund += royaltyAmount;
//     fund.incentiveFund += incentiveAmount;
//     fund.companyIncome += companyIncome;

//     await fund.save();

//     res.json({
//       message: 'Cashback assigned successfully',
//       customerId: customer.customerId,
//       updatedPoints: customer.points,
//     });
//   } catch (err) {
//     console.error(err);
//     res.status(500).send('Server error');
//   }
// });

// // Seller View Customers
// app.get('/dashboard/seller/customers', authenticateToken, async (req, res) => {
//   const seller = await User.findByPk(req.user._id);
//   if (!seller || seller.userType !== 'seller') {
//     return res.status(403).send('Access denied');
//   }

//   const customers = await User.findAll({ where: { userType: 'customer' } });

//   // Categorize customers
//   const goldenCustomers = customers.filter(c => c.points >= 100);
//   const activeCustomers = customers.filter(async c => {
//     const twoMonthsAgo = new Date();
//     twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2);

//     const totalPoints = await Transaction.sum('pointsEarned', {
//       where: {
//         customerId: c.customerId,
//         createdAt: {
//           [Op.gte]: twoMonthsAgo,
//         },
//       },
//     });

//     return totalPoints >= 60;
//   });
//   const highPointCustomers = customers.filter(c => c.points >= 1000);

//   res.json({
//     goldenCustomers,
//     activeCustomers,
//     highPointCustomers,
//   });
// });

// // Seller Send Message
// app.post('/dashboard/seller/send-message', authenticateToken, async (req, res) => {
//   const seller = await User.findByPk(req.user._id);
//   if (!seller || seller.userType !== 'seller') {
//     return res.status(403).send('Access denied');
//   }

//   const { content } = req.body;

//   // Delete previous messages
//   await Message.destroy({ where: {} });

//   // Create new message
//   await Message.create({ content });

//   res.json({ message: 'Message sent to all customers' });
// });

// // Seller View Funds
// app.get('/dashboard/seller/funds', authenticateToken, async (req, res) => {
//   const seller = await User.findByPk(req.user._id);
//   if (!seller || seller.userType !== 'seller') {
//     return res.status(403).send('Access denied');
//   }

//   const fund = await Fund.findOne();

//   res.json({
//     bonusFund: fund.bonusFund,
//     royaltyFund: fund.royaltyFund,
//     incentiveFund: fund.incentiveFund,
//     companyIncome: fund.companyIncome,
//     sellerIncome: seller.balance,
//   });
// });

// // Customer Withdraw Request
// app.post('/dashboard/customer/withdraw', authenticateToken, async (req, res) => {
//   const user = await User.findByPk(req.user._id);
//   if (!user || user.userType !== 'customer') {
//     return res.status(403).send('Access denied');
//   }

//   const { amount, paymentMethod } = req.body;

//   if (amount < 10 || amount > 1000) {
//     return res.status(400).send('Withdrawal amount must be between 10 and 1000');
//   }

//   if (user.balance < amount) {
//     return res.status(400).send('Insufficient balance');
//   }

//   // Create withdraw request
//   await WithdrawRequest.create({
//     userId: user.id,
//     amount,
//     paymentMethod,
//   });

//   res.json({ message: 'Withdraw request submitted' });
// });

// // Seller View Withdraw Requests
// app.get('/dashboard/seller/withdraw-requests', authenticateToken, async (req, res) => {
//   const seller = await User.findByPk(req.user._id);
//   if (!seller || seller.userType !== 'seller') {
//     return res.status(403).send('Access denied');
//   }

//   const requests = await WithdrawRequest.findAll({ where: { status: 'pending' } });

//   res.json({ requests });
// });

// // Seller Approve Withdraw Request
// app.post('/dashboard/seller/approve-withdraw', authenticateToken, async (req, res) => {
//   const seller = await User.findByPk(req.user._id);
//   if (!seller || seller.userType !== 'seller') {
//     return res.status(403).send('Access denied');
//   }

//   const { requestId } = req.body;

//   const request = await WithdrawRequest.findByPk(requestId);
//   if (!request || request.status !== 'pending') {
//     return res.status(404).send('Withdraw request not found or already processed');
//   }

//   const customer = await User.findByPk(request.userId);

//   // Update balance
//   if (customer.balance < request.amount) {
//     return res.status(400).send('Customer has insufficient balance');
//   }

//   customer.balance -= request.amount;
//   await customer.save();

//   // Update withdraw request status
//   request.status = 'approved';
//   await request.save();

//   res.json({ message: 'Withdraw request approved' });
// });

// // Cron Jobs

// // Bonus Distribution (Every 2 months)
// // cron.schedule('0 0 1 */2 *', async () => {
// //   try {
// //     const fund = await Fund.findOne();

// //     const twoMonthsAgo = new Date();
// //     twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2);

// //     // Find active golden customers
// //     const activeGoldenCustomers = await User.findAll({
// //       where: {
// //         isGoldenCustomer: true,
// //       },
// //     });

// //     const qualifyingCustomers = [];

// //     for (const customer of activeGoldenCustomers) {
// //       const totalPoints = await Transaction.sum('pointsEarned', {
// //         where: {
// //           customerId: customer.customerId,
// //           createdAt: {
// //             [Op.gte]: twoMonthsAgo,
// //           },
// //         },
// //       });

// //       if (totalPoints >= 60) {
// //         qualifyingCustomers.push(customer);
// //       }
// //     }

// //     const numberOfCustomers = qualifyingCustomers.length;
// //     if (numberOfCustomers > 0 && fund.bonusFund > 0) {
// //       const perCustomerBonus = fund.bonusFund / numberOfCustomers;

// //       for (const customer of qualifyingCustomers) {
// //         customer.balance += perCustomerBonus;
// //         customer.earnedBonus += perCustomerBonus; // Update earned bonus
// //         await customer.save();
// //       }

// //       // Reset bonus fund
// //       fund.bonusFund = 0;
// //       await fund.save();
// //     }
// //   } catch (err) {
// //     console.error('Error in bonus distribution cron job:', err);
// //   }
// // });

// cron.schedule('* * * * *', async () => {
//   try {
//     const fund = await Fund.findOne();

//     const twoMonthsAgo = new Date();
//     twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2);

//     // Find active golden customers
//     const activeGoldenCustomers = await User.findAll({
//       where: {
//         isGoldenCustomer: true,
//       },
//     });

//     const qualifyingCustomers = [];

//     for (const customer of activeGoldenCustomers) {
//       const totalPoints = await Transaction.sum('pointsEarned', {
//         where: {
//           customerId: customer.customerId,
//           createdAt: {
//             [Op.gte]: twoMonthsAgo,
//           },
//         },
//       });

//       if (totalPoints >= 60) {
//         qualifyingCustomers.push(customer);
//       }
//     }

//     const numberOfCustomers = qualifyingCustomers.length;
//     if (numberOfCustomers > 0 && fund.bonusFund > 0) {
//       const perCustomerBonus = fund.bonusFund / numberOfCustomers;

//       for (const customer of qualifyingCustomers) {
//         customer.balance += perCustomerBonus;
//         customer.earnedBonus += perCustomerBonus; // Update earned bonus
//         await customer.save();
//       }

//       // Reset bonus fund
//       fund.bonusFund = 0;
//       await fund.save();
//     }
//   } catch (err) {
//     console.error('Error in bonus distribution cron job:', err);
//   }
// });




// // Royalty Distribution (Every Friday night)
// cron.schedule('1 0 * * 5', async () => {
//   try {
//     const fund = await Fund.findOne();

//     const goldenCustomers = await User.findAll({
//       where: { isGoldenCustomer: true },
//     });

//     const numberOfCustomers = goldenCustomers.length;
//     if (numberOfCustomers > 0 && fund.royaltyFund > 0) {
//       const perCustomerRoyalty = fund.royaltyFund / numberOfCustomers;

//       for (const customer of goldenCustomers) {
//         customer.balance += perCustomerRoyalty;
//         customer.earnedRoyalty += perCustomerRoyalty; // Update earned royalty
//         await customer.save();
//       }

//       // Reset royalty fund
//       fund.royaltyFund = 0;
//       await fund.save();
//     }
//   } catch (err) {
//     console.error('Error in royalty distribution cron job:', err);
//   }
// });

// // Serve React App (if exists)
// const path = require('path');

// app.use(express.static(path.join(__dirname, 'client', 'build')));

// app.get('*', (req, res) => {
//   res.sendFile(path.join(__dirname, 'client', 'build', 'index.html'));
// });

// // Start the server
// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}`);
// });



// // index.js

// const express = require('express');
// const bodyParser = require('body-parser');
// const cors = require('cors');
// const jwt = require('jsonwebtoken');
// require('dotenv').config();

// const sequelize = require('./config/database');
// const User = require('./models/User');
// const Transaction = require('./models/Transaction');
// const Message = require('./models/Message');
// const WithdrawRequest = require('./models/WithdrawRequest');
// const Fund = require('./models/Fund');
// const authenticateToken = require('./middleware/auth');
// const { Op } = require('sequelize');
// const referralCodes = require('./config/referralCodes');
// const cron = require('node-cron');

// const app = express();
// const PORT = 5000;

// // Middleware
// app.use(bodyParser.json());
// app.use(cors());

// // Model Associations
// WithdrawRequest.belongsTo(User, { as: 'user', foreignKey: 'userId' });
// User.hasMany(WithdrawRequest, { as: 'withdrawRequests', foreignKey: 'userId' });

// // Database connection
// sequelize.sync({ alter: true }).then(async () => {
//   console.log('Connected to MariaDB');

//   // Ensure a Fund record exists
//   const fundRecord = await Fund.findOne();
//   if (!fundRecord) {
//     await Fund.create({});
//   }
// }).catch((err) => {
//   console.error('Error connecting to MariaDB:', err);
// });

// // Routes

// // Registration Route
// app.post('/register', async (req, res) => {
//   const { name, phone, password, userType, referralCode } = req.body;

//   if (!phone) {
//     return res.status(400).send('Please provide phone number.');
//   }

//   try {
//     // Check if phone number already exists
//     const existingPhone = await User.findOne({ where: { phone } });
//     if (existingPhone) {
//       return res.status(400).send('Phone number already registered.');
//     }

//     let customerId = null;

//     if (userType === 'customer') {
//       const lastCustomer = await User.findOne({ where: { userType: 'customer' }, order: [['id', 'DESC']] });
//       let newCustomerId = 'bp2401';

//       if (lastCustomer && lastCustomer.customerId) {
//         const lastIdNumber = parseInt(lastCustomer.customerId.slice(2));
//         newCustomerId = `bp${lastIdNumber + 1}`;
//       }

//       customerId = newCustomerId;
//     }

//     const user = await User.create({
//       name,
//       phone,
//       password,
//       userType,
//       customerId,
//     });

//     // Referral management
//     let referrerCode = referralCode;

//     if (!referrerCode) {
//       // Auto referral code selection
//       const usedCodes = await User.findAll({
//         attributes: ['referralCode'],
//         where: { referralCode: { [Op.in]: referralCodes } },
//       });
//       const usedCodesSet = new Set(usedCodes.map(u => u.referralCode));
//       const availableCodes = referralCodes.filter(code => !usedCodesSet.has(code));

//       if (availableCodes.length > 0) {
//         referrerCode = availableCodes[0]; // Use the first available code
//       } else {
//         referrerCode = referralCodes[0]; // If all codes are used, recycle from the beginning
//       }
//     }

//     user.referralCode = customerId; // Assign customer's own referral code
//     user.referredBy = referrerCode; // Set referrer code

//     await user.save();

//     res.status(201).json({ message: 'User registered successfully', customerId: user.customerId });
//   } catch (err) {
//     console.error(err);
//     res.status(500).send('Error registering user');
//   }
// });

// // Login Route
// app.post('/api/login/:userType', async (req, res) => {
//   const { identifier, password } = req.body;
//   const { userType } = req.params;

//   if (!identifier || !password) {
//     return res.status(400).send('Please provide phone number and password.');
//   }

//   try {
//     // Find user by phone number
//     const user = await User.findOne({
//       where: {
//         userType,
//         phone: identifier,
//       },
//     });

//     if (!user || user.password !== password) {
//       return res.status(400).send('Invalid credentials');
//     }

//     const token = jwt.sign({ _id: user.id, userType: user.userType }, process.env.JWT_SECRET, {
//       expiresIn: process.env.JWT_EXPIRATION,
//     });

//     res.send({ token });
//   } catch (error) {
//     console.error(error);
//     res.status(500).send('Server error');
//   }
// });

// // Customer Dashboard Route
// app.get('/dashboard/customer', authenticateToken, async (req, res) => {
//   try {
//     const user = await User.findByPk(req.user._id);
//     if (!user || user.userType !== 'customer') {
//       return res.status(403).send('Access denied');
//     }

//     // Find referred users
//     const referredUsers = await User.findAll({ where: { referredBy: user.customerId } });

//     // Get the latest message
//     const latestMessage = await Message.findOne({ order: [['createdAt', 'DESC']] });

//     res.json({
//       name: user.name,
//       phone: user.phone,
//       points: user.points,
//       balance: user.balance,
//       earnedBonus: user.earnedBonus,
//       earnedRoyalty: user.earnedRoyalty,
//       earnedIncentive: user.earnedIncentive,
//       earnedReferral: user.earnedReferral,
//       customerId: user.customerId,
//       isGoldenCustomer: user.isGoldenCustomer,
//       referredUsers: referredUsers.map(u => ({ name: u.name, customerId: u.customerId })),
//       totalReferrals: referredUsers.length,
//       message: latestMessage ? latestMessage.content : null,
//     });
//   } catch (err) {
//     console.error(err);
//     res.status(500).send('Server error');
//   }
// });

// // Seller Assign Cashback Route
// app.post('/dashboard/seller/assign-cashback', authenticateToken, async (req, res) => {
//   const { customerId, amount } = req.body;

//   try {
//     const seller = await User.findByPk(req.user._id);
//     if (!seller || seller.userType !== 'seller') {
//       return res.status(403).send('Access denied');
//     }

//     // Find customer
//     const customer = await User.findOne({ where: { customerId } });
//     if (!customer) {
//       return res.status(404).send('Customer not found');
//     }

//     // Convert amount to points
//     const pointsEarned = parseFloat(amount) / 5;
//     customer.points += pointsEarned;

//     // Check for golden customer
//     if (customer.points >= 100) {
//       customer.isGoldenCustomer = true;
//     }

//     await customer.save();

//     // Log transaction
//     await Transaction.create({
//       customerId: customer.customerId,
//       sellerId: seller.id,
//       amount,
//       pointsEarned,
//     });

//     // Fetch fund record
//     const fund = await Fund.findOne();

//     // Referral income calculation
//     const referralIncomeTotal = amount * 0.05; // 5% referral income
//     const generationIncomes = [
//       { percentage: 0.40, level: 1 },
//       { percentage: 0.30, level: 2 },
//       { percentage: 0.30, level: 3 },
//     ];

//     let currentReferrerId = customer.referredBy;
//     for (const income of generationIncomes) {
//       if (!currentReferrerId) break;

//       const referrer = await User.findOne({ where: { customerId: currentReferrerId } });
//       if (referrer) {
//         const incomeAmount = referralIncomeTotal * income.percentage;
//         referrer.balance = (referrer.balance || 0) + incomeAmount;
//         referrer.earnedReferral = (referrer.earnedReferral || 0) + incomeAmount; // Update earned referral income

//         await referrer.save();

//         // Move to next upline referrer
//         currentReferrerId = referrer.referredBy;
//       } else {
//         break;
//       }
//     }

//     // Seller income
//     const sellerIncome = amount * 0.10;
//     seller.balance = (seller.balance || 0) + sellerIncome;
//     await seller.save();

//     // Update funds
//     const bonusAmount = amount * 0.40;
//     const royaltyAmount = amount * 0.10;
//     const incentiveAmount = amount * 0.20;
//     const companyIncome = amount * 0.15;

//     fund.bonusFund += bonusAmount;
//     fund.royaltyFund += royaltyAmount;
//     fund.incentiveFund += incentiveAmount;
//     fund.companyIncome += companyIncome;

//     await fund.save();

//     res.json({
//       message: 'Cashback assigned successfully',
//       customerId: customer.customerId,
//       updatedPoints: customer.points,
//     });
//   } catch (err) {
//     console.error(err);
//     res.status(500).send('Server error');
//   }
// });

// // Seller View Customers
// app.get('/dashboard/seller/customers', authenticateToken, async (req, res) => {
//   const seller = await User.findByPk(req.user._id);
//   if (!seller || seller.userType !== 'seller') {
//     return res.status(403).send('Access denied');
//   }

//   const customers = await User.findAll({ where: { userType: 'customer' } });

//   // Categorize customers
//   const goldenCustomers = customers.filter(c => c.points >= 100);
//   const highPointCustomers = customers.filter(c => c.points >= 1000);

//   // Calculate active customers
//   const activeCustomers = [];
//   const twoMonthsAgo = new Date();
//   twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2);

//   for (const customer of customers) {
//     const totalPoints = await Transaction.sum('pointsEarned', {
//       where: {
//         customerId: customer.customerId,
//         createdAt: {
//           [Op.gte]: twoMonthsAgo,
//         },
//       },
//     });

//     if (totalPoints >= 60) {
//       activeCustomers.push(customer);
//     }
//   }

//   res.json({
//     allCustomers: customers,
//     goldenCustomers,
//     activeCustomers,
//     highPointCustomers,
//   });
// });

// // Seller Send Message
// app.post('/dashboard/seller/send-message', authenticateToken, async (req, res) => {
//   const seller = await User.findByPk(req.user._id);
//   if (!seller || seller.userType !== 'seller') {
//     return res.status(403).send('Access denied');
//   }

//   const { content } = req.body;

//   // Delete previous messages
//   await Message.destroy({ where: {} });

//   // Create new message
//   await Message.create({ content });

//   res.json({ message: 'Message sent to all customers' });
// });

// // Seller View Funds
// app.get('/dashboard/seller/funds', authenticateToken, async (req, res) => {
//   const seller = await User.findByPk(req.user._id);
//   if (!seller || seller.userType !== 'seller') {
//     return res.status(403).send('Access denied');
//   }

//   const fund = await Fund.findOne();

//   res.json({
//     name: seller.name, // Include seller's name
//     bonusFund: fund.bonusFund,
//     royaltyFund: fund.royaltyFund,
//     incentiveFund: fund.incentiveFund,
//     companyIncome: fund.companyIncome,
//     sellerIncome: seller.balance,
//   });
// });

// // Customer Withdraw Request
// app.post('/dashboard/customer/withdraw', authenticateToken, async (req, res) => {
//   const user = await User.findByPk(req.user._id);
//   if (!user || user.userType !== 'customer') {
//     return res.status(403).send('Access denied');
//   }

//   const { amount, paymentMethod } = req.body;

//   if (amount < 10 || amount > 1000) {
//     return res.status(400).send('Withdrawal amount must be between 10 and 1000');
//   }

//   if (user.balance < amount) {
//     return res.status(400).send('Insufficient balance');
//   }

//   // Update balance
//   user.balance -= amount;
//   await user.save();

//   // Create withdraw request
//   await WithdrawRequest.create({
//     userId: user.id,
//     amount,
//     paymentMethod,
//   });

//   res.json({ message: 'Withdraw request submitted' });
// });

// // Seller View Withdraw Requests
// app.get('/dashboard/seller/withdraw-requests', authenticateToken, async (req, res) => {
//   const seller = await User.findByPk(req.user._id);
//   if (!seller || seller.userType !== 'seller') {
//     return res.status(403).send('Access denied');
//   }

//   const requests = await WithdrawRequest.findAll({
//     where: { status: 'pending' },
//     include: [{ model: User, as: 'user' }],
//   });

//   res.json({ requests });
// });

// // Seller Approve Withdraw Request
// app.post('/dashboard/seller/approve-withdraw', authenticateToken, async (req, res) => {
//   const seller = await User.findByPk(req.user._id);
//   if (!seller || seller.userType !== 'seller') {
//     return res.status(403).send('Access denied');
//   }

//   const { requestId } = req.body;

//   const request = await WithdrawRequest.findByPk(requestId);
//   if (!request || request.status !== 'pending') {
//     return res.status(404).send('Withdraw request not found or already processed');
//   }

//   const customer = await User.findByPk(request.userId);

//   // No need to update balance here since it was already deducted when the customer submitted the request
//   // Update withdraw request status
//   request.status = 'approved';
//   await request.save();

//   res.json({ message: 'Withdraw request approved' });
// });

// // Cron Jobs

// // Bonus Distribution (Every 2 months)
// cron.schedule('0 0 1 */2 *', async () => {
//   try {
//     const fund = await Fund.findOne();

//     const twoMonthsAgo = new Date();
//     twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2);

//     // Find active golden customers
//     const activeGoldenCustomers = await User.findAll({
//       where: {
//         isGoldenCustomer: true,
//       },
//     });

//     const qualifyingCustomers = [];

//     for (const customer of activeGoldenCustomers) {
//       const totalPoints = await Transaction.sum('pointsEarned', {
//         where: {
//           customerId: customer.customerId,
//           createdAt: {
//             [Op.gte]: twoMonthsAgo,
//           },
//         },
//       });

//       if (totalPoints >= 60) {
//         qualifyingCustomers.push(customer);
//       }
//     }

//     const numberOfCustomers = qualifyingCustomers.length;
//     if (numberOfCustomers > 0 && fund.bonusFund > 0) {
//       const perCustomerBonus = fund.bonusFund / numberOfCustomers;

//       for (const customer of qualifyingCustomers) {
//         customer.balance += perCustomerBonus;
//         customer.earnedBonus += perCustomerBonus; // Update earned bonus
//         await customer.save();
//       }

//       // Reset bonus fund
//       fund.bonusFund = 0;
//       await fund.save();
//     }
//   } catch (err) {
//     console.error('Error in bonus distribution cron job:', err);
//   }
// });

// // Royalty Distribution (Every Friday night)
// cron.schedule('1 0 * * 5', async () => {
//   try {
//     const fund = await Fund.findOne();

//     const goldenCustomers = await User.findAll({
//       where: { isGoldenCustomer: true },
//     });

//     const numberOfCustomers = goldenCustomers.length;
//     if (numberOfCustomers > 0 && fund.royaltyFund > 0) {
//       const perCustomerRoyalty = fund.royaltyFund / numberOfCustomers;

//       for (const customer of goldenCustomers) {
//         customer.balance += perCustomerRoyalty;
//         customer.earnedRoyalty += perCustomerRoyalty; // Update earned royalty
//         await customer.save();
//       }

//       // Reset royalty fund
//       fund.royaltyFund = 0;
//       await fund.save();
//     }
//   } catch (err) {
//     console.error('Error in royalty distribution cron job:', err);
//   }
// });

// // Serve React App (if exists)
// const path = require('path');

// app.use(express.static(path.join(__dirname, 'client', 'build')));

// app.get('*', (req, res) => {
//   res.sendFile(path.join(__dirname, 'client', 'build', 'index.html'));
// });

// // Start the server
// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}`);
// });



// index.js

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const sequelize = require('./config/database');
const User = require('./models/User');
const Transaction = require('./models/Transaction');
const Message = require('./models/Message');
const WithdrawRequest = require('./models/WithdrawRequest');
const Fund = require('./models/Fund');
const authenticateToken = require('./middleware/auth');
const { Op } = require('sequelize');
const referralCodes = require('./config/referralCodes');
const cron = require('node-cron');

const app = express();
const PORT = 5000;

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Model Associations
//WithdrawRequest.belongsTo(User, { as: 'user', foreignKey: 'userId' });
//User.hasMany(WithdrawRequest, { as: 'withdrawRequests', foreignKey: 'userId' });

// Database connection
sequelize.sync({ alter: true }).then(async () => {
  console.log('Connected to MariaDB');

  // Ensure a Fund record exists
  const fundRecord = await Fund.findOne();
  if (!fundRecord) {
    await Fund.create({});
  }
}).catch((err) => {
  console.error('Error connecting to MariaDB:', err);
});

// Routes

// Registration Route
app.post('/register', async (req, res) => {
  const { name, phone, password, userType, referralCode } = req.body;

  if (!phone) {
    return res.status(400).send('Please provide phone number.');
  }

  try {
    // Check if phone number already exists
    const existingPhone = await User.findOne({ where: { phone } });
    if (existingPhone) {
      return res.status(400).send('Phone number already registered.');
    }

    let customerId = null;

    if (userType === 'customer') {
      const lastCustomer = await User.findOne({ where: { userType: 'customer' }, order: [['id', 'DESC']] });
      let newCustomerId = 'bp2401';

      if (lastCustomer && lastCustomer.customerId) {
        const lastIdNumber = parseInt(lastCustomer.customerId.slice(2));
        newCustomerId = `bp${lastIdNumber + 1}`;
      }

      customerId = newCustomerId;
    }

    const user = await User.create({
      name,
      phone,
      password,
      userType,
      customerId,
    });

    // Referral management
    let referrerCode = referralCode;

    if (!referrerCode) {
      // Auto referral code selection
      const usedCodes = await User.findAll({
        attributes: ['referralCode'],
        where: { referralCode: { [Op.in]: referralCodes } },
      });
      const usedCodesSet = new Set(usedCodes.map(u => u.referralCode));
      const availableCodes = referralCodes.filter(code => !usedCodesSet.has(code));

      if (availableCodes.length > 0) {
        referrerCode = availableCodes[0]; // Use the first available code
      } else {
        referrerCode = referralCodes[0]; // If all codes are used, recycle from the beginning
      }
    }

    user.referralCode = customerId; // Assign customer's own referral code
    user.referredBy = referrerCode; // Set referrer code

    await user.save();

    res.status(201).json({ message: 'User registered successfully', customerId: user.customerId });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error registering user');
  }
});

// Login Route
app.post('/api/login/:userType', async (req, res) => {
  const { identifier, password } = req.body;
  const { userType } = req.params;

  if (!identifier || !password) {
    return res.status(400).send('Please provide phone number and password.');
  }

  try {
    // Find user by phone number
    const user = await User.findOne({
      where: {
        userType,
        phone: identifier,
      },
    });

    if (!user || user.password !== password) {
      return res.status(400).send('Invalid credentials');
    }

    const token = jwt.sign({ _id: user.id, userType: user.userType }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRATION,
    });

    res.send({ token });
  } catch (error) {
    console.error(error);
    res.status(500).send('Server error');
  }
});

// Customer Dashboard Route
app.get('/dashboard/customer', authenticateToken, async (req, res) => {
  try {
    const user = await User.findByPk(req.user._id);
    if (!user || user.userType !== 'customer') {
      return res.status(403).send('Access denied');
    }

    // Find referred users
    const referredUsers = await User.findAll({ where: { referredBy: user.customerId } });

    // Get the latest message
    const latestMessage = await Message.findOne({ order: [['createdAt', 'DESC']] });

    res.json({
      name: user.name,
      phone: user.phone,
      points: user.points,
      balance: user.balance,
      earnedBonus: user.earnedBonus,
      earnedRoyalty: user.earnedRoyalty,
      earnedIncentive: user.earnedIncentive,
      earnedReferral: user.earnedReferral,
      customerId: user.customerId,
      isGoldenCustomer: user.isGoldenCustomer,
      referredUsers: referredUsers.map(u => ({ name: u.name, customerId: u.customerId })),
      totalReferrals: referredUsers.length,
      message: latestMessage ? latestMessage.content : null,
    });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

// Seller Assign Cashback Route
app.post('/dashboard/seller/assign-cashback', authenticateToken, async (req, res) => {
  const { customerId, amount } = req.body;

  try {
    const seller = await User.findByPk(req.user._id);
    if (!seller || seller.userType !== 'seller') {
      return res.status(403).send('Access denied');
    }

    // Find customer
    const customer = await User.findOne({ where: { customerId } });
    if (!customer) {
      return res.status(404).send('Customer not found');
    }

    // Convert amount to points
    const pointsEarned = parseFloat(amount) / 5;
    customer.points += pointsEarned;

    // Check for golden customer
    if (customer.points >= 100) {
      customer.isGoldenCustomer = true;
    }

    await customer.save();

    // Log transaction
    await Transaction.create({
      customerId: customer.customerId,
      sellerId: seller.id,
      amount,
      pointsEarned,
    });

    // Fetch fund record
    const fund = await Fund.findOne();

    // Referral income calculation
    const referralIncomeTotal = amount * 0.05; // 5% referral income
    const generationIncomes = [
      { percentage: 0.40, level: 1 },
      { percentage: 0.30, level: 2 },
      { percentage: 0.30, level: 3 },
    ];

    let currentReferrerId = customer.referredBy;
    for (const income of generationIncomes) {
      if (!currentReferrerId) break;

      const referrer = await User.findOne({ where: { customerId: currentReferrerId } });
      if (referrer) {
        const incomeAmount = referralIncomeTotal * income.percentage;
        referrer.balance = (referrer.balance || 0) + incomeAmount;
        referrer.earnedReferral = (referrer.earnedReferral || 0) + incomeAmount; // Update earned referral income

        await referrer.save();

        // Move to next upline referrer
        currentReferrerId = referrer.referredBy;
      } else {
        break;
      }
    }

    // Seller income
    const sellerIncome = amount * 0.10;
    seller.balance = (seller.balance || 0) + sellerIncome;
    await seller.save();

    // Update funds
    const bonusAmount = amount * 0.40;
    const royaltyAmount = amount * 0.10;
    const incentiveAmount = amount * 0.20;
    const companyIncome = amount * 0.15;

    fund.bonusFund += bonusAmount;
    fund.royaltyFund += royaltyAmount;
    fund.incentiveFund += incentiveAmount;
    fund.companyIncome += companyIncome;

    await fund.save();

    res.json({
      message: 'Cashback assigned successfully',
      customerId: customer.customerId,
      updatedPoints: customer.points,
    });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

// Seller View Customers
app.get('/dashboard/seller/customers', authenticateToken, async (req, res) => {
  const seller = await User.findByPk(req.user._id);
  if (!seller || seller.userType !== 'seller') {
    return res.status(403).send('Access denied');
  }

  const customers = await User.findAll({ where: { userType: 'customer' } });

  // Categorize customers
  const goldenCustomers = customers.filter(c => c.points >= 100);
  const highPointCustomers = customers.filter(c => c.points >= 1000);

  // Calculate active customers
  const activeCustomers = [];
  const twoMonthsAgo = new Date();
  twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2);

  for (const customer of customers) {
    const totalPoints = await Transaction.sum('pointsEarned', {
      where: {
        customerId: customer.customerId,
        createdAt: {
          [Op.gte]: twoMonthsAgo,
        },
      },
    });

    if (totalPoints >= 60) {
      activeCustomers.push(customer);
    }
  }

  res.json({
    allCustomers: customers,
    goldenCustomers,
    activeCustomers,
    highPointCustomers,
  });
});

// Seller Send Message
app.post('/dashboard/seller/send-message', authenticateToken, async (req, res) => {
  const seller = await User.findByPk(req.user._id);
  if (!seller || seller.userType !== 'seller') {
    return res.status(403).send('Access denied');
  }

  const { content } = req.body;

  // Delete previous messages
  await Message.destroy({ where: {} });

  // Create new message
  await Message.create({ content });

  res.json({ message: 'Message sent to all customers' });
});

// Seller View Funds
app.get('/dashboard/seller/funds', authenticateToken, async (req, res) => {
  const seller = await User.findByPk(req.user._id);
  if (!seller || seller.userType !== 'seller') {
    return res.status(403).send('Access denied');
  }

  const fund = await Fund.findOne();

  res.json({
    name: seller.name, // Include seller's name
    bonusFund: fund.bonusFund,
    royaltyFund: fund.royaltyFund,
    incentiveFund: fund.incentiveFund,
    companyIncome: fund.companyIncome,
    sellerIncome: seller.balance,
  });
});

// Customer Withdraw Request
app.post('/dashboard/customer/withdraw', authenticateToken, async (req, res) => {
  const user = await User.findByPk(req.user._id);
  if (!user || user.userType !== 'customer') {
    return res.status(403).send('Access denied');
  }

  const { amount, paymentMethod, phoneNumber } = req.body; // ফোন নম্বর গ্রহণ করা

  if (amount < 10 || amount > 1000) {
    return res.status(400).send('Withdrawal amount must be between 10 and 1000');
  }

  if (user.balance < amount) {
    return res.status(400).send('Insufficient balance');
  }

  // Update balance
  user.balance -= amount;
  await user.save();

  // Create withdraw request with phoneNumber
  await WithdrawRequest.create({
    userId: user.id,
    amount,
    paymentMethod,
    phoneNumber, // ফোন নম্বর সেভ করা
  });

  res.json({ message: 'Withdraw request submitted' });
});

// Seller View Withdraw Requests
app.get('/dashboard/seller/withdraw-requests', authenticateToken, async (req, res) => {
  const seller = await User.findByPk(req.user._id);
  if (!seller || seller.userType !== 'seller') {
    return res.status(403).send('Access denied');
  }

  const requests = await WithdrawRequest.findAll({
    // সব উইথড্র রিকুয়েস্ট ফেচ করা হচ্ছে
    include: [{ model: User, as: 'user' }],
    order: [['createdAt', 'DESC']], // সর্বশেষ রিকুয়েস্টগুলো আগে দেখানোর জন্য
  });

  res.json({ requests });
});

// Seller Approve Withdraw Request
app.post('/dashboard/seller/approve-withdraw', authenticateToken, async (req, res) => {
  const seller = await User.findByPk(req.user._id);
  if (!seller || seller.userType !== 'seller') {
    return res.status(403).send('Access denied');
  }

  const { requestId } = req.body;

  const request = await WithdrawRequest.findByPk(requestId);
  if (!request || request.status !== 'pending') {
    return res.status(404).send('Withdraw request not found or already processed');
  }

  const customer = await User.findByPk(request.userId);

  // No need to update balance here since it was already deducted when the customer submitted the request
  // Update withdraw request status and approvedAt
  request.status = 'approved';
  request.approvedAt = new Date(); // অ্যাপ্রুভের সময় সেভ করা
  await request.save();

  res.json({ message: 'Withdraw request approved' });
});

// Cron Jobs

// Bonus Distribution (Every 2 months)
cron.schedule('0 0 1 */2 *', async () => {
  try {
    const fund = await Fund.findOne();

    const twoMonthsAgo = new Date();
    twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2);

    // Find active golden customers
    const activeGoldenCustomers = await User.findAll({
      where: {
        isGoldenCustomer: true,
      },
    });

    const qualifyingCustomers = [];

    for (const customer of activeGoldenCustomers) {
      const totalPoints = await Transaction.sum('pointsEarned', {
        where: {
          customerId: customer.customerId,
          createdAt: {
            [Op.gte]: twoMonthsAgo,
          },
        },
      });

      if (totalPoints >= 60) {
        qualifyingCustomers.push(customer);
      }
    }

    const numberOfCustomers = qualifyingCustomers.length;
    if (numberOfCustomers > 0 && fund.bonusFund > 0) {
      const perCustomerBonus = fund.bonusFund / numberOfCustomers;

      for (const customer of qualifyingCustomers) {
        customer.balance += perCustomerBonus;
        customer.earnedBonus += perCustomerBonus; // Update earned bonus
        await customer.save();
      }

      // Reset bonus fund
      fund.bonusFund = 0;
      await fund.save();
    }
  } catch (err) {
    console.error('Error in bonus distribution cron job:', err);
  }
});



// Royalty Distribution (Every Friday night)
cron.schedule('1 0 * * 5', async () => {
  try {
    const fund = await Fund.findOne();

    const goldenCustomers = await User.findAll({
      where: { isGoldenCustomer: true },
    });

    const numberOfCustomers = goldenCustomers.length;
    if (numberOfCustomers > 0 && fund.royaltyFund > 0) {
      const perCustomerRoyalty = fund.royaltyFund / numberOfCustomers;

      for (const customer of goldenCustomers) {
        customer.balance += perCustomerRoyalty;
        customer.earnedRoyalty += perCustomerRoyalty; // Update earned royalty
        await customer.save();
      }

      // Reset royalty fund
      fund.royaltyFund = 0;
      await fund.save();
    }
  } catch (err) {
    console.error('Error in royalty distribution cron job:', err);
  }
});

// Serve React App (if exists)
const path = require('path');

app.use(express.static(path.join(__dirname, 'client', 'build')));

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'client', 'build', 'index.html'));
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
