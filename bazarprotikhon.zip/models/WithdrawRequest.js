// // models/WithdrawRequest.js

// const { DataTypes } = require('sequelize');
// const sequelize = require('../config/database');

// const WithdrawRequest = sequelize.define('WithdrawRequest', {
//   userId: { type: DataTypes.INTEGER, allowNull: false },
//   amount: { type: DataTypes.FLOAT, allowNull: false },
//   paymentMethod: { type: DataTypes.STRING, allowNull: false },
//   status: { 
//     type: DataTypes.STRING, 
//     defaultValue: 'pending',
//     validate: { isIn: [['pending', 'approved', 'rejected']] },
//   },
// }, {
//   timestamps: true,
// });

// module.exports = WithdrawRequest;


const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');

const WithdrawRequest = sequelize.define('WithdrawRequest', {
  userId: { type: DataTypes.INTEGER, allowNull: false },
  amount: { type: DataTypes.FLOAT, allowNull: false },
  paymentMethod: { type: DataTypes.STRING, allowNull: false },
  phoneNumber: { type: DataTypes.STRING, allowNull: false }, // এখানে phoneNumber ফিল্ড যোগ করা হয়েছে
  status: { 
    type: DataTypes.STRING, 
    defaultValue: 'pending',
    validate: { isIn: [['pending', 'approved', 'rejected']] },
  },
  approvedAt: { // approvedAt ফিল্ড
    type: DataTypes.DATE,
    allowNull: true,
  },
}, {
  timestamps: true,
});

// এসোসিয়েশন সেটআপ
WithdrawRequest.belongsTo(User, { as: 'user', foreignKey: 'userId' });

module.exports = WithdrawRequest;
