// // models/Message.js

// const { DataTypes } = require('sequelize');
// const sequelize = require('../config/database');

// const Message = sequelize.define('Message', {
//   content: { type: DataTypes.TEXT, allowNull: false },
// }, {
//   timestamps: true,
// });

// module.exports = Message;



// models/Message.js

const { Model, DataTypes } = require('sequelize');
const sequelize = require('../config/database');

class Message extends Model {}

Message.init(
  {
    content: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
  },
  {
    sequelize,
    modelName: 'Message',
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
  }
);

module.exports = Message;
