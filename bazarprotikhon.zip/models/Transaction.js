// // models/Transaction.js

// const { DataTypes } = require('sequelize');
// const sequelize = require('../config/database');

// const Transaction = sequelize.define('Transaction', {
//   customerId: { type: DataTypes.STRING, allowNull: false },
//   sellerId: { type: DataTypes.INTEGER, allowNull: false },
//   amount: { type: DataTypes.FLOAT, allowNull: false },
//   pointsEarned: { type: DataTypes.FLOAT, allowNull: false },
//   date: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
// });

// module.exports = Transaction;



// models/Transaction.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Transaction = sequelize.define('Transaction', {
  customerId: { type: DataTypes.STRING, allowNull: false },
  sellerId: { type: DataTypes.INTEGER, allowNull: false },
  amount: { type: DataTypes.FLOAT, allowNull: false },
  pointsEarned: { type: DataTypes.FLOAT, allowNull: false },
  date: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
}, {
  timestamps: true  // `createdAt` এবং `updatedAt` ফিল্ড যোগ হবে
});

module.exports = Transaction;
