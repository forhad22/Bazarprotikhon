// // models/Fund.js

// const { DataTypes } = require('sequelize');
// const sequelize = require('../config/database');

// const Fund = sequelize.define('Fund', {
//   bonusFund: {
//     type: DataTypes.FLOAT,
//     defaultValue: 0,
//   },
//   royaltyFund: {
//     type: DataTypes.FLOAT,
//     defaultValue: 0,
//   },
//   incentiveFund: {
//     type: DataTypes.FLOAT,
//     defaultValue: 0,
//   },
//   companyIncome: {
//     type: DataTypes.FLOAT,
//     defaultValue: 0,
//   },
// }, {
//   timestamps: true,
// });

// module.exports = Fund;


// models/Fund.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');  // আপনার ডাটাবেস কনফিগারেশন ফাইল

// Fund মডেল ডিফাইনেশন
const Fund = sequelize.define('Fund', {
  bonusFund: {
    type: DataTypes.FLOAT,
    defaultValue: 0,
  },
  royaltyFund: {
    type: DataTypes.FLOAT,
    defaultValue: 0,
  },
  incentiveFund: {
    type: DataTypes.FLOAT,
    defaultValue: 0,
  },
  companyIncome: {
    type: DataTypes.FLOAT,
    defaultValue: 0,
  },
  sellerIncome: { // নতুন sellerIncome ফিল্ড
    type: DataTypes.FLOAT,
    defaultValue: 0,
  },
}, {
  timestamps: true,  // এই অপশনটি অবজেক্ট তৈরি হলে টাইমস্ট্যাম্প তৈরি করবে
});

module.exports = Fund;
