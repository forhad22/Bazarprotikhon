
// const { DataTypes } = require('sequelize');
// const sequelize = require('../config/database');

// const User = sequelize.define('User', {
//   name: { 
//     type: DataTypes.STRING, 
//     allowNull: false,  // Name is required
//   },
//   phone: { 
//     type: DataTypes.STRING, 
//     unique: true, 
//     allowNull: true,  // Phone is optional, must be unique if provided
//     validate: { len: [10, 15] }  // Example validation for phone length
//   },
//   password: { 
//     type: DataTypes.STRING, 
//     allowNull: false  // Password is required
//   },
//   userType: { 
//     type: DataTypes.STRING, 
//     allowNull: false,  // 'customer' or 'seller'
//     validate: { isIn: [['customer', 'seller']] }  // Must be either 'customer' or 'seller'
//   },
//   customerId: { 
//     type: DataTypes.STRING, 
//     unique: true, 
//     allowNull: true  // Unique customer ID, generated for customers
//   },
//   points: { 
//     type: DataTypes.FLOAT, 
//     defaultValue: 0  // Default points value is 0
//   },
//   referralCode: { 
//     type: DataTypes.STRING, 
//     allowNull: true  // Optional referral code
//   },
//   referredBy: { 
//     type: DataTypes.STRING, 
//     allowNull: true  // Optional referral tracking
//   },
//   isGoldenCustomer: { 
//     type: DataTypes.BOOLEAN, 
//     defaultValue: false  // Boolean flag for golden customer
//   }
// }, {
//   timestamps: true  // This will add `createdAt` and `updatedAt` fields
// });

// module.exports = User;







// models/User.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const User = sequelize.define('User', {
  name: { 
    type: DataTypes.STRING, 
    allowNull: false,  // নাম অবশ্যই দিতে হবে
  },
  phone: { 
    type: DataTypes.STRING, 
    unique: true, 
    allowNull: true,  // ফোন নম্বর ঐচ্ছিক, তবে ইউনিক হতে হবে
    validate: { len: [10, 15] }  // ফোন নম্বরের দৈর্ঘ্য চেক
  },
  password: { 
    type: DataTypes.STRING, 
    allowNull: false  // পাসওয়ার্ড অবশ্যই দিতে হবে
  },
  userType: { 
    type: DataTypes.STRING, 
    allowNull: false,  // 'customer' বা 'seller' হতে হবে
    validate: { isIn: [['customer', 'seller']] }
  },
  customerId: { 
    type: DataTypes.STRING, 
    unique: true, 
    allowNull: true  // ইউনিক কাস্টমার আইডি
  },
  points: { 
    type: DataTypes.FLOAT, 
    defaultValue: 0  // ডিফল্ট পয়েন্টস 0
  },
  balance: { 
    type: DataTypes.FLOAT, 
    defaultValue: 0  // ইউজারের ব্যালেন্স
  },
  referralCode: { 
    type: DataTypes.STRING, 
    allowNull: true  // ইউজারের নিজের রেফারেল কোড
  },
  referredBy: { 
    type: DataTypes.STRING, 
    allowNull: true  // রেফারারের কোড
  },
  isGoldenCustomer: { 
    type: DataTypes.BOOLEAN, 
    defaultValue: false  // গোল্ডেন কাস্টমার ফ্ল্যাগ
  },
  earnedBonus: {
    type: DataTypes.FLOAT,
    defaultValue: 0,  // অর্জিত বোনাস
  },
  earnedRoyalty: {
    type: DataTypes.FLOAT,
    defaultValue: 0,  // অর্জিত রয়্যালটি
  },
  earnedIncentive: {
    type: DataTypes.FLOAT,
    defaultValue: 0,  // অর্জিত ইনসেন্টিভ
  },
  earnedReferral: {
    type: DataTypes.FLOAT,
    defaultValue: 0,  // অর্জিত রেফারেল ইনকাম
  },
}, {
  timestamps: true  // `createdAt` এবং `updatedAt` ফিল্ড যোগ হবে
});

module.exports = User;
