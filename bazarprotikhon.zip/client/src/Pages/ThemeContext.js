// ThemeContext.js
import React, { createContext, useContext, useEffect, useState } from 'react';

const ThemeContext = createContext();

export const ThemeProvider = ({ children }) => {
  const [isNightMode, setIsNightMode] = useState(() => {
    const savedTheme = localStorage.getItem('nightMode');
    return savedTheme ? JSON.parse(savedTheme) : false;
  });

  const toggleNightMode = () => {
    const newMode = !isNightMode;
    setIsNightMode(newMode);
    localStorage.setItem('nightMode', JSON.stringify(newMode));
  };

  useEffect(() => {
    const savedTheme = localStorage.getItem('nightMode');
    if (savedTheme !== null) {
      setIsNightMode(JSON.parse(savedTheme));
    }
  }, []);

  return (
    <ThemeContext.Provider value={{ isNightMode, toggleNightMode }}>
      {children}
    </ThemeContext.Provider>
  );
};


const themeStyles = {
  light: {
    backgroundColor: 'white',
    color: 'black',
    fontFamily: "'Hind Siliguri', sans-serif",
  },
  dark: {
    backgroundColor: 'black',
    color: 'white',
    fontFamily: "'Baloo Da 2', sans-serif",
  },
};


export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
