// config/referralCodes.js

module.exports = [
  'REFCODE1',
  'REFCODE2',
  'REFCODE3',
  'REFCODE4',
  'REFCODE5',
  'REFCODE6',
  'REFCODE7',
  'REFCODE8',
  'REFCODE9',
  'REFCODE10',
];
