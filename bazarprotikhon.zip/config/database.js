
// const { Sequelize } = require('sequelize');
// require('dotenv').config();

// const dbDialect = process.env.DB_DIALECT || 'mysql'; // ডায়ালেক্ট পরিবর্তনশীল
// const sequelize = new Sequelize(process.env.DB_NAME, process.env.DB_USER, process.env.DB_PASSWORD, {
//   host: process.env.DB_HOST,
//   dialect: dbDialect,
//   port: process.env.DB_PORT || (dbDialect === 'mariadb' ? 3307 : 3306), // পোর্ট নির্ধারণ
// });

// // সংযোগ যাচাই করা
// sequelize.authenticate()
//   .then(() => {
//     console.log('Connection has been established successfully.');
//   })
//   .catch(err => {
//     console.error('Unable to connect to the database:', err);
//   });

// module.exports = sequelize;




// config/database.js

const { Sequelize } = require('sequelize');
require('dotenv').config();

const dbDialect = process.env.DB_DIALECT || 'mysql'; // ডায়ালেক্ট

const sequelize = new Sequelize(process.env.DB_NAME, process.env.DB_USER, process.env.DB_PASSWORD, {
  host: process.env.DB_HOST,
  dialect: dbDialect,
  port: process.env.DB_PORT || (dbDialect === 'mariadb' ? 3307 : 3306),
  dialectOptions: {
    charset: 'utf8mb4',
  },
  define: {
    charset: 'utf8mb4',
    collate: 'utf8mb4_unicode_ci',
  },
});

// সংযোগ যাচাই করা
sequelize.authenticate()
  .then(() => {
    console.log('Connection has been established successfully with utf8mb4 charset.');
  })
  .catch(err => {
    console.error('Unable to connect to the database:', err);
  });

module.exports = sequelize;
